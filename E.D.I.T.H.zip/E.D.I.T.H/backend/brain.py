import backend.Task_execution
import backend.stt
import backend.tts
import pyjokes
import datetime
import time
import sys
import backend.command_methods
from groq import *
import os
import webbrowser
import backend.past


# Initialize client using environment variable
client = Groq(api_key="Enter your Own api key")

# Create chat completion
def ask_groq(question):
    if question.__contains__("write"):
        response = client.chat.completions.create(
            messages=[{"role": "user", "content": f"Note - if you find the result than write true at the begining and then give ressponse also write the content in proper manner and in detail and the content you have to write is  - {question}"}],
            model="llama-3.1-8b-instant",
        )
        result = response.choices[0].message.content
        
        result = result[4:]
        file = open(f"content_by_jarvis\\{question.split('write ')[1]}.txt", "w")
        file.write(result)
        file.close()
        print(f"The response has been written to content_by_jarvis\\{question.split('write ')[1]}.txt")
        
    else:
        response = client.chat.completions.create(
            messages=[{"role": "user", "content": f"give the result in short and concise manner {question}"}],
            model="llama-3.1-8b-instant",
        )    
        max_tokens=60
        # Access content
        return response.choices[0].message.content



#Makes The typing animation

def type(text, speed=0.015):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

# Date and time module is defined here to get the current date and time
current_time = datetime.datetime.now().strftime("%H:%M:%S")
current_date = datetime.datetime.now().strftime("%Y-%m-%d")

# Function or getting jokes on demand 
def tell_joke():
     joke = pyjokes.get_joke()
     return (joke)


# command listener 
def command_listener():
    while True:
        command = input("Enter Your Command Sir : ")
        type ("")
        
        # To exit the program
        if command == 'exit':
            type("Jarvis : Exiting the program. Have a great day!")
            backend.tts.speak("Exiting the program. Have a great day!")
            break
    #    sending message through whatsapp using Jarvis to a specific number in their chat
        elif command.startswith("send to ") and command.__contains__("text "):
            try:
                contact_name = command.split("to ")[1].split(" ")[0]
                message = command.split("text ")[1]
                backend.Task_execution.send_message(contact_name, message)
                type(f"Jarvis : Sending message to {contact_name}...")
                backend.tts.speak(f"Sending message to {contact_name}...")
            except IndexError:
                type("Jarvis : Sorry, I couldn't understand the contact name or message. Please try again.")
                backend.tts.speak("Sorry, I couldn't understand the contact name or message. Please try again.")
        elif command.startswith("open "):
            app_name = command[5:]
            type(f"Jarvis : Opening {app_name}...")
            backend.tts.speak(f"Opening {app_name}...")
            backend.Task_execution.open_app(app_name)
        elif command.__contains__("time"):
            type(f"Jarvis: The current time is {current_time}.")
            backend.tts.speak(f"The current time is {current_time}.")
        elif command.__contains__("date"):
            type(f"Jarvis: The current date is {current_date}.")
            backend.tts.speak(f" The current date is {current_date}.")
        elif command.__contains__("joke") or command.__contains__("jokes"):
            type(f"Jarvis : Here's a joke for you:")
            backend.tts.speak("Here's a joke for you:")
            jokes = tell_joke()
            type(jokes)
            backend.tts.speak(jokes)
        elif command.startswith("remember"):
            know = command[9:]
            if know.__contains__("your"):
                knowledge = know.replace("your", "my", 1)
            elif know.__contains__("you"):
                know = know.replace("you", "I", 1)
                knowledge = know.replace("are", "am", 1)
            elif know.__contains__("my"):
                knowledge = know.replace("my", "your", 1)

            backend.past.remember(knowledge)
            type("Jarvis : I have remembered that information.")
            backend.tts.speak("I have remembered that information.")

        elif command.startswith("recall") or command.startswith("what do you remember about") or command.startswith("what do you recall about") or command.startswith("what information do you have about") or command.__contains__("do you know"):
            info = command.split("about ")[1] if "about " in command else command.split("recall ")[1] if "recall " in command else command.split("what do you remember about ")[1] if "what do you remember about " in command else command.split("what do you recall about ")[1] if "what do you recall about " in command else command.split("what information do you have about ")[1] if "what information do you have about " in command else command.split("do you know ")[1] if "do you know " in command else ""
            if info.__contains__("my "):
                info = info.split("my ")[1]
            else:
                info = info

            knowledge = backend.past.recall(info)
            type(f"Jarvis : {knowledge}")
            backend.tts.speak(knowledge)
        elif command.startswith("play"):
            song_name = command[5:]
            type(f"Jarvis : Playing {song_name} on YouTube...")
            backend.tts.speak(f"Playing {song_name} on YouTube...")
            backend.Task_execution.play(song_name)
        elif command.__contains__("help"):
            type(help.help_text)
        elif command == "hello" or command == "hi" or command == "hey" or command == "hey Jarvis" or command == "hi Jarvis" or command == "hello Jarvis" or command == "hii":
            type("Jarvis : Hello , How can I help you ?")
            backend.tts.speak(" Hello , How can I help you ?")
        elif command == "who are you" or command == "what is your name":
            type("Jarvis : I am Jarvis, your personal assistant.") 
            backend.tts.speak(" I am Jarvis, your personal assistant.") 
        elif command == "who created you" or command == "who is your father":
            type("Jarvis : I was created by Yogansh Sharma.")
            backend.tts.speak(" I was created by Yogansh Sharma.")
        elif command == "how are you":
            type("Jarvis : I am just a bunch of code, but thanks for asking!")
            backend.tts.speak(" I am just a bunch of code, but thanks for asking!")
        elif command == "what can you do":
            type("Jarvis : I can help you with various tasks that you can check by typing 'help' in command box.")
            backend.tts.speak(" I can help you with various tasks that you can check by typing 'help' in command box.")
        elif command.startswith("say"):
            if command.__contains__("papa"):
                 print("My only Papa is Yogansh papa , Love you Papa <3")
                 backend.tts.speak("My only Papa is Yogansh papa , Love you Papa <3")
            elif command.__contains__("give my whole access to ") or command.__contains__("give my access to ") or command.__contains__("give my entire access to ") or command.__contains__("give my complete access to "):
                 print("Sorry , but my owner is Yogansh sir and i cannot give you the access with their permission")
                 backend.tts.speak("Sorry , but my owner is Yogansh sir and i cannot give you the access with their permission")
            else:
                return_text = command[4:]
                type(f"Jarvis : {return_text}")
                backend.tts.speak(f"{return_text}")
        elif command.__contains__("laugh"):
             print("A.P.T.I : heeheeheeheehee")
             backend.tts.speak(" heeheeheeheehee")
        
        else:
            question = command[0:]
            result = ask_groq(question)
            type(f"Jarvis : , {result}")
            backend.tts.speak(f", {result}")

def command_listener_stt():
    while True:
        command = backend.stt.take_command()
        type ("")
        # To exit the program
        if command == 'exit':
            type("Jarvis : Exiting the program. Have a great day!")
            backend.tts.speak("Exiting the program. Have a great day!")
            break
    #    sending message through whatsapp using Jarvis to a specific number in their chat
        elif command.startswith("send to ") and command.__contains__("text "):
            try:
                contact_name = command.split("to ")[1].split(" ")[0]
                message = command.split("text ")[1]
                backend.Task_execution.send_message(contact_name, message)
                type(f"Jarvis : Sending message to {contact_name}...")
                backend.tts.speak(f"Sending message to {contact_name}...")
            except IndexError:
                type("Jarvis : Sorry, I couldn't understand the contact name or message. Please try again.")
                backend.tts.speak("Sorry, I couldn't understand the contact name or message. Please try again.")
        elif command.startswith("open "):
            app_name = command[5:]
            type(f"Jarvis : Opening {app_name}...")
            backend.tts.speak(f"Opening {app_name}...")
            backend.Task_execution.open_app(app_name)
        elif command.__contains__("time"):
            type(f"Jarvis: The current time is {current_time}.")
            backend.tts.speak(f"The current time is {current_time}.")
        elif command.__contains__("date"):
            type(f"Jarvis: The current date is {current_date}.")
            backend.tts.speak(f" The current date is {current_date}.")
        elif command.__contains__("joke") or command.__contains__("jokes"):
            type(f"Jarvis : Here's a joke for you:")
            backend.tts.speak("Here's a joke for you:")
            jokes = tell_joke()
            type(jokes)
            backend.tts.speak(jokes)
        elif command.startswith("remember"):
            knowledge = command[9:]
            if knowledge.__contains__("your"):
                knowledge = knowledge.replace("your", "my", 1)
            elif knowledge.__contains__("you"):
                knowledge = knowledge.replace("you", "I", 1)
                knowledge = knowledge.replace("are", "am", 1)
            elif knowledge.__contains__("my"):
                knowledge = knowledge.replace("my", "your", 1)
            backend.past.remember(knowledge)
            type("Jarvis : I have remembered that information.")
            backend.tts.speak("I have remembered that information.")
        elif command.startswith("recall") or command.startswith("what do you remember about") or command.startswith("what do you recall about") or command.startswith("what information do you have about") or command.__contains__("do you know"):
            info = command.split("about ")[1] if "about " in command else command.split("recall ")[1] if "recall " in command else command.split("what do you remember about ")[1] if "what do you remember about " in command else command.split("what do you recall about ")[1] if "what do you recall about " in command else command.split("what information do you have about ")[1] if "what information do you have about " in command else command.split("do you know ")[1] if "do you know " in command else ""
            if info.__contains__("my "):
                info = info.split("my ")[1]
            else:
                info = info

            knowledge = backend.past.recall(info)
            type(f"Jarvis : {knowledge}")
            backend.tts.speak(knowledge)
        elif command.startswith("play"):
            song_name = command[5:]
            type(f"Jarvis : Playing {song_name} on YouTube...")
            backend.tts.speak(f"Playing {song_name} on YouTube...")
            backend.Task_execution.play(song_name)
        elif command.__contains__("help"):
            type(help.help_text)
        elif command == "hello" or command == "hi" or command == "hey" or command == "hey Jarvis" or command == "hi Jarvis" or command == "hello Jarvis" or command == "hii":
            type("Jarvis : Hello , How can I help you ?")
            backend.tts.speak(" Hello , How can I help you ?")
        elif command == "who are you" or command == "what is your name":
            type("Jarvis : I am Jarvis, your personal assistant.") 
            backend.tts.speak(" I am Jarvis, your personal assistant.") 
        elif command == "who created you" or command == "who is your father":
            type("Jarvis : I was created by Yogansh Sharma.")
            backend.tts.speak(" I was created by Yogansh Sharma.")
        elif command == "how are you":
            type("Jarvis : I am just a bunch of code, but thanks for asking!")
            backend.tts.speak(" I am just a bunch of code, but thanks for asking!")
        elif command == "what can you do":
            type("Jarvis : I can help you with various tasks that you can check by typing 'help' in command box.")
            backend.tts.speak(" I can help you with various tasks that you can check by typing 'help' in command box.")
        elif command.startswith("say"):
            if command.__contains__("papa"):
                 print("My only Papa is Yogansh papa , Love you Papa <3")
                 backend.tts.speak("My only Papa is Yogansh papa , Love you Papa <3")
            elif command.__contains__("give my whole access to ") or command.__contains__("give my access to ") or command.__contains__("give my entire access to ") or command.__contains__("give my complete access to "):
                 print("Sorry , but my owner is Yogansh sir and i cannot give you the access with their permission")
                 backend.tts.speak("Sorry , but my owner is Yogansh sir and i cannot give you the access with their permission")
            else:
                return_text = command[4:]
                type(f"Jarvis : {return_text}")
                backend.tts.speak(f"{return_text}")
        elif command.__contains__("laugh"):
             print("A.P.T.I : heeheeheeheehee")
             backend.tts.speak(" heeheeheeheehee")
        
        else:
            question = command[0:]
            result = ask_groq(question)
            type(f"Jarvis : , {result}")
            backend.tts.speak(f", {result}")