import pyttsx3

engine = pyttsx3.init()

def speak(text):
        """Convert text to speech"""
        # print(f"{text}")
        engine.setProperty('rate', 150)  # Adjust the speech rate (optional)
        engine.say(text)
        engine.runAndWait()

