
# this function enables E.D.I.T.H to remember any information that the user wants her to remember and saves it in a text file named "remember.txt"

def remember(knowledge):
    with open("backend/remember.txt", "a") as file:
        if knowledge.__contains__("my "):
            file.write("your " + knowledge.split("my ")[1] + "\n")
        elif knowledge.__contains__("i "):
            file.write("you " + knowledge.split("i ")[1] + "\n")
        else:
            file.write(knowledge + "\n")
    print("Okay sir , I will remember that information for you !")

# this function allows E.D.I.T.H to recall the information that the user asked her to remember and reads it out loud to the user
def recall(info):
    with open("database/remember.txt", "r") as file:
        for line in file:
            if info.lower() in line.lower():
                return line.strip()

    return "I don't remember that information."
        
