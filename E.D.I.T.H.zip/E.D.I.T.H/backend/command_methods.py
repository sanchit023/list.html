import brain

def method_c (method):
    if method.__contains__("keyboard"):
        brain.command_listener()
    elif method.__contains__("voice") or method.__contains__("speech") or method.__contains__("mic") or method.__contains__("microphone"):
        brain.command_listener_stt()
    else:
        print("Invalid method selected. Please choose either 'keyboard' or 'voice'.")
    

