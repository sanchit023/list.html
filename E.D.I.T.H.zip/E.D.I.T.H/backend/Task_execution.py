import os
import webbrowser

def open_app(app_name):
    if app_name == "notepad":
        os.startfile("notepad.exe")
    elif app_name == "calculator":
        os.startfile("calc.exe")
    elif app_name == "valorant":
        os.startfile("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Riot Games")
    elif app_name == "msedge":
        os.startfile("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe")
    elif app_name == "clock":
        os.startfile("clock.exe")
    elif app_name == "youtube":
        webbrowser.open("https://www.youtube.com")
    elif app_name == "spotify":
        webbrowser.open("https://www.spotify.com")
    elif app_name == "minecraft":
        webbrowser.open("https://www.minecraft.com")
    elif app_name == "github":
        webbrowser.open("https://www.github.com")
    elif app_name == "gmail":
        webbrowser.open("https://mail.google.com")
    elif app_name == "Discord":
        webbrowser.open("https://discord.gg")       
    elif app_name == "Google":
        webbrowser.open("https://Google.in")       
    else :
        try : 
            os.startfile(app_name)
        except :webbrowser.open(f"https://www.{app_name}.com")

# Playing songs on youtube 
def play(song_name):
    if song_name.__contains__("youtube"):
        webbrowser.open(f"https://www.youtube.com/results?search_query={song_name}")
    else : 
        song_name.replace(" " ,"%20", len(song_name))
        webbrowser.open(f"https://open.spotify.com/search/{song_name}")

# This function allows Edith to open whatsapp and write messae to a specific number in their chat 
def send_message(contact_name, message):
    webbrowser.open(f"https://wa.me/{contact_name}?text={message}")


