import backend.tts
import backend.brain
import backend.command_methods

backend.brain.type("Initialising J.A.R.V.I.S")
backend.tts.speak("Initialising Jarvis")
backend.brain.type("J.A.R.V.I.S  is ready to assist you !")
backend.tts.speak("Jarvis is ready to assist you !")
backend.brain.type("J.A.R.V.I.S : Hello sir , I am your personal assistant how can i help you sir ?")
backend.tts.speak("Hello sir , I am your personal assistant , how can i help you sir ?")

# backend.brain.command_listener()
method = input("Enter the method for the Entire conversation : ")
backend.command_methods.method_c(method)
